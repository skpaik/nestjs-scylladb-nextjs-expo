-- Create database if not exists
CREATE DATABASE ecommerce;

-- Connect to the database
\c ecommerce;

-- Create products table
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    index_number INTEGER UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    brand VARCHAR(100),
    category VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    stock INTEGER DEFAULT 0,
    ean BIGINT,
    color VARCHAR(50),
    size VARCHAR(20),
    availability VARCHAR(20) DEFAULT 'in_stock',
    short_description TEXT,
    image VARCHAR(255),
    internal_id UUID NOT NULL DEFAULT gen_random_uuid(),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_brand ON products(brand);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_products_availability ON products(availability);
CREATE INDEX idx_products_name ON products(name);

-- Insert sample data
INSERT INTO products (index_number, name, description, brand, category, price, currency, stock, ean, color, size, availability, short_description, image, internal_id) VALUES
(1, 'Thermostat Drone Heater', '<div><p><strong>Thermostat Drone Heater</strong> is a top product in our <em>Kitchen Appliances</em> category.</p><p>Price: <span style="color:green;">$74</span> (USD)</p><p>Brand: Bradford-Yu</p><p>Available in color: <span style="color:orchid;">Orchid</span>, size: Medium</p><p>Stock status: backorder, 139 units left.</p><p>EAN: 8619793560985</p></div>', 'Bradford-Yu', 'Kitchen Appliances', 74.00, 'USD', 139, 8619793560985, 'Orchid', 'Medium', 'backorder', 'Consumer approach woman us those star.', '1.jpg', '6ce4b628-2bcc-4829-8c64-b3a71bf09a60'),
(2, 'Smart Coffee Maker', '<div><p><strong>Smart Coffee Maker</strong> with WiFi connectivity and mobile app control.</p><p>Price: <span style="color:green;">$129</span> (USD)</p><p>Brand: TechBrew</p><p>Available in color: <span style="color:black;">Black</span>, size: Large</p><p>Stock status: in_stock, 45 units left.</p></div>', 'TechBrew', 'Kitchen Appliances', 129.00, 'USD', 45, 1234567890123, 'Black', 'Large', 'in_stock', 'Smart coffee maker with app control', '2.jpg', gen_random_uuid()),
(3, 'Wireless Bluetooth Headphones', '<div><p><strong>Premium Wireless Headphones</strong> with noise cancellation.</p><p>Price: <span style="color:green;">$199</span> (USD)</p><p>Brand: AudioTech</p><p>Available in color: <span style="color:blue;">Blue</span>, size: One Size</p><p>Stock status: in_stock, 78 units left.</p></div>', 'AudioTech', 'Electronics', 199.00, 'USD', 78, 9876543210987, 'Blue', 'One Size', 'in_stock', 'Premium wireless headphones with ANC', '3.jpg', gen_random_uuid()),
(4, 'Fitness Tracker Watch', '<div><p><strong>Advanced Fitness Tracker</strong> with heart rate monitoring.</p><p>Price: <span style="color:green;">$89</span> (USD)</p><p>Brand: FitTech</p><p>Available in color: <span style="color:red;">Red</span>, size: Medium</p><p>Stock status: low_stock, 12 units left.</p></div>', 'FitTech', 'Wearables', 89.00, 'USD', 12, 5555444433332, 'Red', 'Medium', 'low_stock', 'Advanced fitness tracker with heart rate monitor', '4.jpg', gen_random_uuid()),
(5, 'Smartphone Stand', '<div><p><strong>Adjustable Smartphone Stand</strong> for desk use.</p><p>Price: <span style="color:green;">$24</span> (USD)</p><p>Brand: DeskHelper</p><p>Available in color: <span style="color:silver;">Silver</span>, size: Small</p><p>Stock status: in_stock, 200 units left.</p></div>', 'DeskHelper', 'Accessories', 24.00, 'USD', 200, 1111222233334, 'Silver', 'Small', 'in_stock', 'Adjustable smartphone stand for desk', '5.jpg', gen_random_uuid());