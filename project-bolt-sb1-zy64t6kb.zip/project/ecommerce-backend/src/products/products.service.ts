import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, Between, In } from 'typeorm';
import { Product } from './entities/product.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { SearchProductDto } from './dto/search-product.dto';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
  ) {}

  async create(createProductDto: CreateProductDto): Promise<Product> {
    const product = this.productRepository.create({
      ...createProductDto,
      internalId: createProductDto.internalId || require('crypto').randomUUID(),
    });
    return await this.productRepository.save(product);
  }

  async findAll(query: ProductQueryDto) {
    const { page, limit, category, brand, minPrice, maxPrice, sortBy, sortOrder } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.productRepository.createQueryBuilder('product');

    // Apply filters
    if (category) {
      queryBuilder.andWhere('product.category = :category', { category });
    }

    if (brand) {
      queryBuilder.andWhere('product.brand = :brand', { brand });
    }

    if (minPrice !== undefined) {
      queryBuilder.andWhere('product.price >= :minPrice', { minPrice });
    }

    if (maxPrice !== undefined) {
      queryBuilder.andWhere('product.price <= :maxPrice', { maxPrice });
    }

    // Apply sorting
    if (sortBy && ['name', 'price', 'createdAt'].includes(sortBy)) {
      queryBuilder.orderBy(`product.${sortBy}`, sortOrder);
    } else {
      queryBuilder.orderBy('product.createdAt', 'DESC');
    }

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [items, total] = await queryBuilder.getManyAndCount();

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findOne(id: number): Promise<Product> {
    const product = await this.productRepository.findOne({ where: { id } });
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }

  async findByInternalId(internalId: string): Promise<Product> {
    const product = await this.productRepository.findOne({ where: { internalId } });
    if (!product) {
      throw new NotFoundException(`Product with internal ID ${internalId} not found`);
    }
    return product;
  }

  async search(searchDto: SearchProductDto) {
    const { q, page, limit, category, brand } = searchDto;
    const skip = (page - 1) * limit;

    const queryBuilder = this.productRepository.createQueryBuilder('product');

    // Search in name, description, and short description
    queryBuilder.where(
      '(product.name ILIKE :search OR product.description ILIKE :search OR product.shortDescription ILIKE :search)',
      { search: `%${q}%` }
    );

    // Apply additional filters
    if (category) {
      queryBuilder.andWhere('product.category = :category', { category });
    }

    if (brand) {
      queryBuilder.andWhere('product.brand = :brand', { brand });
    }

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    // Order by relevance (name matches first, then description matches)
    queryBuilder.orderBy(
      `CASE 
        WHEN product.name ILIKE :exactSearch THEN 1
        WHEN product.name ILIKE :search THEN 2
        WHEN product.shortDescription ILIKE :search THEN 3
        ELSE 4
      END`,
      'ASC'
    );
    queryBuilder.setParameter('exactSearch', `%${q}%`);
    queryBuilder.setParameter('search', `%${q}%`);

    const [items, total] = await queryBuilder.getManyAndCount();

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      query: q,
    };
  }

  async findLatest(limit: number = 10): Promise<Product[]> {
    return await this.productRepository.find({
      order: { createdAt: 'DESC' },
      take: limit,
    });
  }

  async findFeatured(limit: number = 10): Promise<Product[]> {
    // For now, return products with highest stock as "featured"
    // You can modify this logic based on your business requirements
    return await this.productRepository.find({
      where: { availability: 'in_stock' },
      order: { stock: 'DESC' },
      take: limit,
    });
  }

  async findByCategory(category: string, limit: number = 10): Promise<Product[]> {
    return await this.productRepository.find({
      where: { category },
      order: { createdAt: 'DESC' },
      take: limit,
    });
  }

  async findByBrand(brand: string, limit: number = 10): Promise<Product[]> {
    return await this.productRepository.find({
      where: { brand },
      order: { createdAt: 'DESC' },
      take: limit,
    });
  }

  async getCategories(): Promise<string[]> {
    const result = await this.productRepository
      .createQueryBuilder('product')
      .select('DISTINCT product.category', 'category')
      .where('product.category IS NOT NULL')
      .getRawMany();
    
    return result.map(item => item.category);
  }

  async getBrands(): Promise<string[]> {
    const result = await this.productRepository
      .createQueryBuilder('product')
      .select('DISTINCT product.brand', 'brand')
      .where('product.brand IS NOT NULL')
      .getRawMany();
    
    return result.map(item => item.brand);
  }

  async update(id: number, updateProductDto: UpdateProductDto): Promise<Product> {
    const product = await this.findOne(id);
    Object.assign(product, updateProductDto);
    return await this.productRepository.save(product);
  }

  async remove(id: number): Promise<void> {
    const product = await this.findOne(id);
    await this.productRepository.remove(product);
  }

  async updateStock(id: number, quantity: number): Promise<Product> {
    const product = await this.findOne(id);
    product.stock = quantity;
    
    // Update availability based on stock
    if (quantity === 0) {
      product.availability = 'out_of_stock';
    } else if (quantity < 20) {
      product.availability = 'low_stock';
    } else {
      product.availability = 'in_stock';
    }
    
    return await this.productRepository.save(product);
  }
}