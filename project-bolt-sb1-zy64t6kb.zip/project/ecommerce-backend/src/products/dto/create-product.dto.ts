import { IsNotEmpty, IsOptional, IsNumber, IsString, IsPositive, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateProductDto {
  @ApiProperty({ description: 'Product index number', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  indexNumber: number;

  @ApiProperty({ description: 'Product name', example: 'Thermostat Drone Heater' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Product description', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ description: 'Product brand', example: 'Bradford-Yu', required: false })
  @IsOptional()
  @IsString()
  brand?: string;

  @ApiProperty({ description: 'Product category', example: 'Kitchen Appliances', required: false })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiProperty({ description: 'Product price', example: 74.00 })
  @IsNumber()
  @IsPositive()
  price: number;

  @ApiProperty({ description: 'Currency', example: 'USD', default: 'USD' })
  @IsOptional()
  @IsString()
  currency?: string;

  @ApiProperty({ description: 'Stock quantity', example: 139, default: 0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  stock?: number;

  @ApiProperty({ description: 'EAN code', required: false })
  @IsOptional()
  @IsNumber()
  ean?: number;

  @ApiProperty({ description: 'Product color', example: 'Orchid', required: false })
  @IsOptional()
  @IsString()
  color?: string;

  @ApiProperty({ description: 'Product size', example: 'Medium', required: false })
  @IsOptional()
  @IsString()
  size?: string;

  @ApiProperty({ description: 'Availability status', example: 'backorder', default: 'in_stock' })
  @IsOptional()
  @IsString()
  availability?: string;

  @ApiProperty({ description: 'Short description', required: false })
  @IsOptional()
  @IsString()
  shortDescription?: string;

  @ApiProperty({ description: 'Product image filename', example: '1.jpg', required: false })
  @IsOptional()
  @IsString()
  image?: string;

  @ApiProperty({ description: 'Internal UUID', required: false })
  @IsOptional()
  @IsString()
  internalId?: string;
}