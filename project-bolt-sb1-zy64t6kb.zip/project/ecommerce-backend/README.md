# E-commerce Backend API

A comprehensive NestJS backend API for e-commerce web and mobile applications.

## Features

- **Product Management**: Full CRUD operations for products
- **Search & Filtering**: Advanced search with pagination and filtering
- **Category & Brand Management**: Organize products by categories and brands
- **Stock Management**: Track product availability and stock levels
- **API Documentation**: Swagger/OpenAPI documentation
- **Database**: PostgreSQL with TypeORM
- **Validation**: Input validation with class-validator
- **Docker Support**: Docker Compose for easy development setup

## API Endpoints

### Products
- `GET /api/products` - Get all products with pagination and filtering
- `GET /api/products/:id` - Get product by ID
- `GET /api/products/internal/:internalId` - Get product by internal UUID
- `GET /api/products/search` - Search products by name and description
- `GET /api/products/latest` - Get latest products
- `GET /api/products/featured` - Get featured products
- `GET /api/products/categories` - Get all product categories
- `GET /api/products/brands` - Get all product brands
- `GET /api/products/category/:category` - Get products by category
- `GET /api/products/brand/:brand` - Get products by brand
- `POST /api/products` - Create a new product
- `PATCH /api/products/:id` - Update product by ID
- `PATCH /api/products/:id/stock` - Update product stock
- `DELETE /api/products/:id` - Delete product by ID

### Query Parameters for /api/products

- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)
- `category` - Filter by category
- `brand` - Filter by brand
- `minPrice` - Minimum price filter
- `maxPrice` - Maximum price filter
- `sortBy` - Sort by field (name, price, createdAt)
- `sortOrder` - Sort order (ASC, DESC)

### Search Parameters for /api/products/search

- `q` - Search query (required)
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)
- `category` - Filter by category
- `brand` - Filter by brand

## Getting Started

### Prerequisites

- Node.js 18+ 
- Docker and Docker Compose
- PostgreSQL (if not using Docker)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the database using Docker:
```bash
docker-compose up -d
```

3. Copy environment variables:
```bash
cp .env.example .env
```

4. Start the development server:
```bash
npm run start:dev
```

The API will be available at `http://localhost:3000`

### API Documentation

Once the server is running, you can access the Swagger API documentation at:
`http://localhost:3000/api-docs`

### Database Commands

```bash
# Start database
npm run docker:up

# Stop database
npm run docker:down

# View logs
docker-compose logs -f postgres
```

## Database Schema

The main Product entity includes:

- `id` - Primary key
- `indexNumber` - Unique product index
- `name` - Product name
- `description` - Full HTML description
- `shortDescription` - Brief description
- `brand` - Product brand
- `category` - Product category
- `price` - Product price
- `currency` - Price currency (default: USD)
- `stock` - Stock quantity
- `ean` - EAN barcode
- `color` - Product color
- `size` - Product size
- `availability` - Stock status (in_stock, low_stock, out_of_stock, backorder)
- `image` - Image filename
- `internalId` - UUID for internal reference
- `createdAt` - Creation timestamp
- `updatedAt` - Last update timestamp

## Development

### Running Tests

```bash
# Unit tests
npm run test

# Test coverage
npm run test:cov

# End-to-end tests
npm run test:e2e
```

### Building for Production

```bash
npm run build
npm run start:prod
```

## Docker Support

The project includes Docker Compose configuration for:

- PostgreSQL database
- Redis cache (for future use)

Both services are configured with persistent volumes and proper networking.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the UNLICENSED License.