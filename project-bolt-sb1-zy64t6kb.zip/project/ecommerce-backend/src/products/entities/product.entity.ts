import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Index } from 'typeorm';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'index_number', unique: true })
  @Index()
  indexNumber: number;

  @Column({ length: 255 })
  @Index()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ length: 100, nullable: true })
  @Index()
  brand: string;

  @Column({ length: 100, nullable: true })
  @Index()
  category: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  @Index()
  price: number;

  @Column({ length: 3, default: 'USD' })
  currency: string;

  @Column({ default: 0 })
  stock: number;

  @Column({ type: 'bigint', nullable: true })
  ean: number;

  @Column({ length: 50, nullable: true })
  color: string;

  @Column({ length: 20, nullable: true })
  size: string;

  @Column({ length: 20, default: 'in_stock' })
  @Index()
  availability: string;

  @Column({ type: 'text', nullable: true })
  shortDescription: string;

  @Column({ length: 255, nullable: true })
  image: string;

  @Column({ name: 'internal_id', type: 'uuid' })
  internalId: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}